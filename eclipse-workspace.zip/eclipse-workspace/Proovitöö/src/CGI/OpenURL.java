package CGI;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
public class OpenURL {
 
	@Test
	public void CGI_Proovit��() throws Exception{
 

WebDriver driver = new ChromeDriver();
 
//Navigate to a website
driver.get("http://automationpractice.com/index.php");

//Mazimize browser window
driver.manage().window().maximize();

// Choose TAB Women
WebElement svgObject = driver.findElement(By.xpath("//*[@id='block_top_menu']/ul/li[1]/a"));
Actions builder = new Actions(driver);
builder.click(svgObject).build().perform();

Thread.sleep(4000);

//Choose TAB TOPS
WebElement svgObject2 = driver.findElement(By.xpath("//*[@id=\"categories_block_left\"]/div/ul/li[1]/a[contains(text(),'Tops')]"));
Actions builder2 = new Actions(driver);
builder2.click(svgObject2).build().perform();

//Choose TAB T-shirts
boolean staleElement = true; 

while(staleElement){

  try{

     driver.findElement(By.xpath("//*[@id=\"subcategories\"]/ul/li[1]/div[1]/a/img")).click();
     
     staleElement = false;


  } catch(StaleElementReferenceException e){

    staleElement = true;
       
  }

}

//Go to the main page using page logo ( Your Logo a new experience )
driver.findElement(By.xpath("//*[@class='logo img-responsive']")).click();

// Push Log in button
driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();

//Insert wrong e-mail aadress
driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Helloo");

//Select Sign in button
driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();

Thread.sleep(2000);

//Check is the fail message correct
String actual_error= driver.findElement(By.xpath("//*[@id=\"center_column\"]/div[1]/ol/li")).getText();
String expected_error="Invalid email address.";

Assert.assertEquals(actual_error,expected_error);

System.out.println("Test completed");

// Close browser
driver.close();
}
 
}



