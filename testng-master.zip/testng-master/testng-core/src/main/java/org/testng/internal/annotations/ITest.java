package org.testng.internal.annotations;

import org.testng.annotations.ITestAnnotation;

public interface ITest extends ITestAnnotation {}
