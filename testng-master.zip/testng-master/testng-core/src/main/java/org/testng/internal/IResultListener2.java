package org.testng.internal;

import org.testng.IConfigurationListener;

public interface IResultListener2 extends IResultListener, IConfigurationListener {}
