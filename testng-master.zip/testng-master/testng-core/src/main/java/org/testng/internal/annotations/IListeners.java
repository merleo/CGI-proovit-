package org.testng.internal.annotations;

import org.testng.annotations.IListenersAnnotation;

public interface IListeners extends IListenersAnnotation {}
