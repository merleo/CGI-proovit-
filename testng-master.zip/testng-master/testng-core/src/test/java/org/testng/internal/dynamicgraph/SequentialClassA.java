package org.testng.internal.dynamicgraph;

import org.testng.annotations.Test;

public class SequentialClassA {

  @Test
  public void testMethodOneSequentialClassA() {}

  @Test
  public void testMethodTwoSequentialClassA() {}
}
