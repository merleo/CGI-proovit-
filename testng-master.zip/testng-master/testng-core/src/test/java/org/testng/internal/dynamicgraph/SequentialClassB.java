package org.testng.internal.dynamicgraph;

import org.testng.annotations.Test;

public class SequentialClassB {

  @Test
  public void testMethodOneSequentialClassB() {}

  @Test
  public void testMethodTwoSequentialClassB() {}
}
