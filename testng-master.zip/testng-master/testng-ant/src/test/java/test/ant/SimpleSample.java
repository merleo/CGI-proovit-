package test.ant;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SimpleSample {

  @Test
  public void test() {
    Assert.assertTrue(true);
  }
}
