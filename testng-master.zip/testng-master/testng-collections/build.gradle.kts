plugins {
    id("testng.java-library")
}
