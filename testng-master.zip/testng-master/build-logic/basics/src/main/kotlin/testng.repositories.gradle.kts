// Can't use settings plugin: https://github.com/gradle/gradle/issues/17295
// dependencyResolutionManagement {
//    repositories {
//        mavenCentral()
//    }
//}

repositories {
    mavenCentral()
}
