plugins {
    id("testng.java")
    `java-platform`
}
