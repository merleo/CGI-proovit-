package org.testng;

// WARNING: Donot delete this interface. This is internally being referred to by Gradle here
// https://github.com/gradle/gradle/blob/f0b9d60906c7b8c42cd6c61a39ae7b74767bb012/subprojects/testing-jvm/src/main/java/org/gradle/api/internal/tasks/testing/testng/TestNGListenerAdapterFactory.java#L37-L49
/** @deprecated As of release 7.0.0, replaced by {@link org.testng.IConfigurationListener} */
@Deprecated
public interface IConfigurationListener2 extends IConfigurationListener {}
