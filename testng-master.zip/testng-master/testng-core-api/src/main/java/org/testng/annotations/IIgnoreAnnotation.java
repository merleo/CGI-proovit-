package org.testng.annotations;

/** Encapsulate the @{@link Ignore} annotation */
public interface IIgnoreAnnotation extends IAnnotation {}
