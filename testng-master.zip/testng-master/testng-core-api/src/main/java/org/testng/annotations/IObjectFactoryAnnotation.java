package org.testng.annotations;

public interface IObjectFactoryAnnotation extends IAnnotation {}
