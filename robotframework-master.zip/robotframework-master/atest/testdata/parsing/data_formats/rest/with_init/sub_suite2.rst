.. code:: robotframework

    ********************* Test Cases* ***************************************
    |  Suite2 Test  |  [Documentation] |  FAIL    |  Expected failure  |
    |               |  Fail            |  ${msg}  |                    |
    |               |                  |          |  |  |  |  |  |  |  |

    ********************* Variables *****************************************
    |  ${msg}  |  Expected failure  |
