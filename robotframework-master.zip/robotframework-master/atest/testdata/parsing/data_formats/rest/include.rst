Included file with some more test data.

.. code:: robotframework

   *** Setting ***
   Default Tags    default1


The end.
