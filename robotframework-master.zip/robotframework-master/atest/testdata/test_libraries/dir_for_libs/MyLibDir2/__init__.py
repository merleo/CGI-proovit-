def keyword_in_my_lib_dir_2(*args):
    return sum([int(i) for i in args])
