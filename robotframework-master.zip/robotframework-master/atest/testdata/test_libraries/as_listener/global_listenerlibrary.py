from listenerlibrary import listenerlibrary


class global_listenerlibrary(listenerlibrary):
    ROBOT_LIBRARY_SCOPE = "GLOBAL"
