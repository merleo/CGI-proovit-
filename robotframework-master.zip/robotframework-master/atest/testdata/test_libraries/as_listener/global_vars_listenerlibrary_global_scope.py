from global_vars_listenerlibrary import global_vars_listenerlibrary


class global_vars_listenerlibrary_global_scope(global_vars_listenerlibrary):
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
