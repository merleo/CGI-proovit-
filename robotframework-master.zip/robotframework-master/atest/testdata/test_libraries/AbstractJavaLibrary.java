public abstract class AbstractJavaLibrary {
}
