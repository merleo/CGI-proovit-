public class InitializationFailJavaLibrary {
	
	public InitializationFailJavaLibrary() {
		throw new RuntimeException("Initialization failed!");
	}

}