# This file is only used by invalid_syntax.html and metadata.html.

variable_file_var = 'Variable from a variable file'
