def get_open_file():
    return open(__file__)