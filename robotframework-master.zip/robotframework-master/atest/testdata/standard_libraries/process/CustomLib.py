class CustomLib:

    def get_process_id(self):
        return "The Pid"
