IMPORT_VARIABLES_1 = 'Simple variable file'
COMMON_VARIABLE = 1
