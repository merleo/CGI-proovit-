class O:
  def __init__(self, n):
    self.n = n
  def __str__(self):
    return self.n


object = O('Hello! ' * 100)

