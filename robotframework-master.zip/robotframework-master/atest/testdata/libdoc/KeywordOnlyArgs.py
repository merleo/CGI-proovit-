def kw_only_args(*, kwo):
    pass


def kw_only_args_with_varargs(*varargs, kwo, another='default'):
    pass
