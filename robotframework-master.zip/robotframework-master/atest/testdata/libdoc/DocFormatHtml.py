from DocFormat import DocFormat


class DocFormatHtml(DocFormat):
    ROBOT_LIBRARY_DOC_FORMAT = 'HtMl'


DocFormatHtml.__doc__ = DocFormat.__doc__
