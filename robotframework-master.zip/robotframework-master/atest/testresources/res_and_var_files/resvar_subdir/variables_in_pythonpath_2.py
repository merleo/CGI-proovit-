def get_variables(*args):
    return { 'PPATH_VARFILE_2' : ' '.join(args),
             'LIST__PPATH_VARFILE_2_LIST' : args }
