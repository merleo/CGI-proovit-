
public class NoHandlers {

    public int handler_count = 0;

    public String str = "no handlers here";
}


