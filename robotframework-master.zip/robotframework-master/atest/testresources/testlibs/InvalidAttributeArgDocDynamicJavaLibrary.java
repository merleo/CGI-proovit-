public class InvalidAttributeArgDocDynamicJavaLibrary {

    public String[] getKeywordNames() {
        return new String[] {"keyword"};
    }

    public Object runKeyword(String name, Object[] args) {
        return null;
    }

    public String getKeywordDocumentation = "invalid";

    public String getKeywordArguments = "invalid";

}
