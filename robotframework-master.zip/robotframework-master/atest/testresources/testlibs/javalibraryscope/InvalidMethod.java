package javalibraryscope;

public class InvalidMethod extends BaseLib{
	
	public static String ROBOT_LIBRARY_SCOPE(){
		return "GLOBAL"; 
	}
	
}