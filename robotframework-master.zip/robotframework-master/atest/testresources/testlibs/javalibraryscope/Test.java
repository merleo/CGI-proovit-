package javalibraryscope;

public class Test extends BaseLib{
	
	public static String ROBOT_LIBRARY_SCOPE = "TESTCASE"; 
	
}