package javalibraryscope;

public class InvalidPrivate extends BaseLib{
	
	private static String ROBOT_LIBRARY_SCOPE = "SUITE"; 
	
}